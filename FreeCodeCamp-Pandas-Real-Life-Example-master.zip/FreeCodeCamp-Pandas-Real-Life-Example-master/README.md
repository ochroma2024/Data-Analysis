
#### We're in the process of adapting these notebooks into interactive projects in [DataWars](https://www.datawars.io/?utm_source=fccrepo&utm_medium=pandas-real-life). Sign up now, it's [completely free](https://www.datawars.io/?utm_source=fccrepo&utm_medium=pandas-real-life).

Stay tuned! Have any questions? [Join our Discord](https://discord.gg/DSTe8tY38T)

---

Created by Santiago Basulto. Connect with me on [X](https://x.com/santiagobasulto) or [LinkedIn](https://www.linkedin.com/in/santiagobasulto/)
